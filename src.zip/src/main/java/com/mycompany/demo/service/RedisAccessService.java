package com.mycompany.demo.service;

import com.mycompany.demo.model.*;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class RedisAccessService {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    // public Employee getEmployeeFromRedis(Long id) {
    //     return (Employee) redisTemplate.opsForValue().get("employeeCache::" + id);
    // }
    // @Value("${demo.redis.key-prefix}")
    // private String redisPrefix;

    public Employee getEmployeeFromRedis(Long id) {
        String key ="employeeCache::" + id;
        Object value = redisTemplate.opsForValue().get(key);
        System.out.println("Redis value for key " + key + ": " + value);
        
        if (!(value instanceof Employee)) {
            System.out.println("Unexpected value type: " + value.getClass());
            return null; // Or throw a custom error
        }
    
        return (Employee) value;
    }
}
